package Controllers;

import ConexionBD.DBUtil;
import ConexionBD.NutrientesModel;
import com.example.shotfood.Usuario;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.*;
import javafx.scene.layout.Pane;
import ConexionBD.UsuarioModel;

import java.io.IOException;
import java.sql.*;

public class SumarNutrientesController {


    @FXML
    private Pane Pane;
    @FXML
    private Label label4;
    @FXML
    private Label label1;
    @FXML
    private Label label2;
    @FXML
    private Label label3;
    private EditarNutrientesController editarNutrientesController;
    @FXML
    private Spinner S3;
    @FXML
    private Spinner S4;
    @FXML
    private Spinner S1;
    @FXML
    private Spinner S2;

    @FXML
    public void Aplicate(ActionEvent actionEvent) {
        Usuario usuario = Usuario.getUsuarioActual();
        NutrientesModel nm = new NutrientesModel();

        // Obtener IDs de nutrientes desde el controlador
        int id1 = editarNutrientesController.idNutriente1();
        int id2 = editarNutrientesController.idNutriente2();
        int id3 = editarNutrientesController.idNutriente3();
        int id4 = editarNutrientesController.idNutriente4();

        // Obtener valores de los spinners (ya son Integer)
        int seguimiento1 = (Integer) S1.getValue();
        int seguimiento2 = (Integer) S2.getValue();
        int seguimiento3 = (Integer) S3.getValue();
        int seguimiento4 = (Integer) S4.getValue();

        // Actualizar el seguimiento para cada nutriente
        nm.updateSeguimiento(usuario.getId(), id1, seguimiento1);
        nm.updateSeguimiento(usuario.getId(), id2, seguimiento2);
        nm.updateSeguimiento(usuario.getId(), id3, seguimiento3);
        nm.updateSeguimiento(usuario.getId(), id4, seguimiento4);
    }


    @FXML
    public void GoBack(ActionEvent actionEvent) throws IOException {
        Pane pane = FXMLLoader.load(getClass().getResource("/com/example/shotfood/Registro.fxml"));
        this.Pane.getChildren().setAll(pane);

    }

    public void initialize(){
        NutrientesModel model = new NutrientesModel();
        Usuario usuario = Usuario.getUsuarioActual();

        int id1 = editarNutrientesController.idNutriente1();
        int id2 = editarNutrientesController.idNutriente2();
        int id3 = editarNutrientesController.idNutriente3();
        int id4 = editarNutrientesController.idNutriente4();

        String p1 = model.getNombreNutriente(usuario.getId(), id1);
        String p2 = model.getNombreNutriente(usuario.getId(), id2);
        String p3 = model.getNombreNutriente(usuario.getId(), id3);
        String p4 = model.getNombreNutriente(usuario.getId(), id4);

        label1.setText(p1);
        label2.setText(p2);
        label3.setText(p3);
        label4.setText(p4);

        S1.setEditable(true);
        S2.setEditable(true);
        S3.setEditable(true);
        S4.setEditable(true);

        Integer seguimiento1 = model.getSeguimientoNutriente(usuario.getId(), id1);
        Integer seguimiento2 = model.getSeguimientoNutriente(usuario.getId(), id2);
        Integer seguimiento3 = model.getSeguimientoNutriente(usuario.getId(), id3);
        Integer seguimiento4 = model.getSeguimientoNutriente(usuario.getId(), id4);

        S1.setValueFactory(new SpinnerValueFactory.IntegerSpinnerValueFactory(0, 1500, seguimiento1));
        S2.setValueFactory(new SpinnerValueFactory.IntegerSpinnerValueFactory(0, 1500, seguimiento2));
        S3.setValueFactory(new SpinnerValueFactory.IntegerSpinnerValueFactory(0, 1500, seguimiento3));
        S4.setValueFactory(new SpinnerValueFactory.IntegerSpinnerValueFactory(0, 1500, seguimiento4));

    }
}
