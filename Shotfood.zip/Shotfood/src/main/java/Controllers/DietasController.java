package Controllers;

import ConexionBD.DietaModel;
import com.example.shotfood.Dieta;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Label;
import javafx.scene.control.TabPane;
import javafx.scene.control.TextArea;
import javafx.scene.control.TitledPane;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.control.ScrollPane;
import javafx.geometry.Insets;


import java.io.IOException;
import java.util.ArrayList;
import java.util.Objects;

public class DietasController {
    @FXML
    private Pane paneDietas;
    @FXML
    private VBox vboxDietas;
    @FXML
    private AnchorPane paneAlmuerzo;
    @FXML
    private AnchorPane paneMerienda;
    @FXML
    private AnchorPane paneDesayuno;
    @FXML
    private AnchorPane paneComida;
    @FXML
    private AnchorPane paneCena;
    @FXML
    private TabPane paneDieta;
    @FXML
    private VBox vboxLunes;
    @FXML
    private AnchorPane paneCena2;
    @FXML
    private AnchorPane paneCena1;
    @FXML
    private VBox vboxMartes;
    @FXML
    private VBox vboxMiercoles;
    @FXML
    private VBox vboxJueves;
    @FXML
    private VBox vboxViernes;
    @FXML
    private VBox vboxSabado;
    @FXML
    private VBox vboxDomingo;
    @FXML
    private Label LabelDieta;

    @FXML
    public void initialize() {
        DietaModel model = new DietaModel();
        for (Dieta d : model.getDietas()) {
            Label label = new Label(d.getNombre());
            label.setStyle("-fx-padding: 5; -fx-font-size: 14;");
            if(d.getTipo() == 1) {
                addToPane(vboxLunes, d.getNombre());
            } else {
                addToPane(vboxLunes, d.getNombre());
            }
            if(d.getTipo() == 2) {
                addToPane(vboxMartes, d.getNombre());
            } else {
                addToPane(vboxMartes, d.getNombre());
            }
            if(d.getTipo() == 3) {
                addToPane(vboxMiercoles, d.getNombre());
            } else {
                addToPane(vboxMiercoles, d.getNombre());
            }
            if(d.getTipo() == 4) {
                addToPane(vboxJueves, d.getNombre());
            } else {
                addToPane(vboxJueves, d.getNombre());
            }
            if(d.getTipo() == 5) {
                addToPane(vboxViernes, d.getNombre());
            } else {
                addToPane(vboxViernes, d.getNombre());
            }
            if(d.getTipo() == 6) {
                addToPane(vboxSabado, d.getNombre());
            } else {
                addToPane(vboxSabado, d.getNombre());
            }
            if(d.getTipo() == 7) {
                addToPane(vboxDomingo, d.getNombre());
            } else {
                addToPane(vboxDomingo, d.getNombre());
            }


        }



        paneDieta.getTabs().forEach(tab -> {
            tab.setStyle(
                    "-fx-font-family: 'Century Gothic';" +
                            "-fx-font-size: 16px;" +  // Un poco más grande, legible en móviles
                            "-fx-padding: 10 20;" +   // Más espacio alrededor
                            "-fx-text-fill: #444;" +  // Gris oscuro profesional
                            "-fx-background-color: #f8f8f8;" +  // Fondo suave
                            "-fx-border-color: #ccc;" +
                            "-fx-border-radius: 12;" +
                            "-fx-background-radius: 12;" +
                            "-fx-effect: dropshadow(one-pass-box, rgba(0,0,0,0.1), 2, 0.0, 0, 2);"
            );
        });
    }

    private void addToPane(VBox vboxDesayunos, String texto) {
        Label label = new Label(texto);
        vboxDesayunos.getChildren().add(label);
    }


    @Deprecated
    public void toUsuario(ActionEvent actionEvent) throws IOException {
        Pane pane = FXMLLoader.load(getClass().getResource("/com/example/shotfood/Usuario.fxml"));
        this.paneDietas.getChildren().setAll(pane);
    }

    @FXML
    public void Salir(ActionEvent actionEvent) throws IOException {
        AnchorPane pane = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("/com/example/shotfood/PantallaPrincipal.fxml")));
        this.paneDietas.getChildren().setAll(pane);
    }

    @Deprecated
    public void GoBack(ActionEvent actionEvent) {
    }
}