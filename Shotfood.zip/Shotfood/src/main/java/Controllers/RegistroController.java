package Controllers;

import ConexionBD.NutrientesModel;
import com.example.shotfood.Nutrientes;
import com.example.shotfood.Usuario;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.ProgressIndicator;
import javafx.scene.layout.Pane;


import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class RegistroController implements Initializable  {

    @FXML
    private Label P1;
    @FXML
    private Label P2;
    @FXML
    private Label N1;
    @FXML
    private Label P3;
    @FXML
    private Label N2;
    @FXML
    private Label P4;
    @FXML
    private Label N3;
    @FXML
    private Label N4;
    private EditarNutrientesController editarNutrientesController;
    @FXML
    private Pane paneregistro;
    @FXML
    private ProgressIndicator barra1;
    @FXML
    private ProgressIndicator barra4;
    @FXML
    private ProgressIndicator barra3;
    @FXML
    private ProgressIndicator barra2;

    @javafx.fxml.FXML
    public void GoBack(ActionEvent actionEvent) throws IOException {
        Pane pane = FXMLLoader.load(getClass().getResource("/com/example/shotfood/PantallaPrincipal.fxml"));
        this.paneregistro.getChildren().setAll(pane);
    }

    @javafx.fxml.FXML
    public void EDIT_info(ActionEvent actionEvent) throws IOException {
        Pane pane = FXMLLoader.load(getClass().getResource("/com/example/shotfood/EditarNutrientes.fxml"));
        this.paneregistro.getChildren().setAll(pane);
    }

    @javafx.fxml.FXML
    public void ADD_more(ActionEvent actionEvent) throws IOException {
        Pane pane = FXMLLoader.load(getClass().getResource("/com/example/shotfood/SumarNutrientes.fxml"));
        this.paneregistro.getChildren().setAll(pane);
    }

    @Deprecated
    public void initialize(URL arg0, ResourceBundle arg1){

        barra1.setStyle("-fx-accent: red");
        barra2.setStyle("-fx-accent: blue");
        barra3.setStyle("-fx-accent: yellow");
        barra4.setStyle("-fx-accent: pink");

        if (editarNutrientesController != null) {

            Usuario usuario = Usuario.getUsuarioActual();
            NutrientesModel model = new NutrientesModel();

            int id1 = editarNutrientesController.idNutriente1();
            int id2 = editarNutrientesController.idNutriente2();
            int id3 = editarNutrientesController.idNutriente3();
            int id4 = editarNutrientesController.idNutriente4();

            int n1 = model.getSeguimientoNutriente(usuario.getId(), id1);
            int n2 = model.getSeguimientoNutriente(usuario.getId(), id2);
            int n3 = model.getSeguimientoNutriente(usuario.getId(), id3);
            int n4 = model.getSeguimientoNutriente(usuario.getId(), id4);

            String p1 = model.getNombreNutriente(usuario.getId(), id1);
            String p2 = model.getNombreNutriente(usuario.getId(), id2);
            String p3 = model.getNombreNutriente(usuario.getId(), id3);
            String p4 = model.getNombreNutriente(usuario.getId(), id4);

            P1.setText(p1);
            P2.setText(p2);
            P3.setText(p3);
            P4.setText(p4);

            Integer numero1 = n1;
            Integer numero2 = n2;
            Integer numero3 = n3;
            Integer numero4 = n4;

            N1.setText(numero1.toString());
            N2.setText(numero2.toString());
            N3.setText(numero3.toString());
            N4.setText(numero4.toString());

            Nutrientes nutriente1 = model.getNutrientePorId(usuario.getId(), id1);
            Nutrientes nutriente2 = model.getNutrientePorId(usuario.getId(), id2);
            Nutrientes nutriente3 = model.getNutrientePorId(usuario.getId(), id3);
            Nutrientes nutriente4 = model.getNutrientePorId(usuario.getId(), id4);

            barra1.setProgress(nutriente1.porcentajeSeguimiento());
            barra2.setProgress(nutriente2.porcentajeSeguimiento());
            barra3.setProgress(nutriente3.porcentajeSeguimiento());
            barra4.setProgress(nutriente4.porcentajeSeguimiento());

        } else {

            System.out.println("editarNutrientesController es null.");
            
            barra1.setProgress(0.01);
            barra2.setProgress(0.01);
            barra3.setProgress(0.01);
            barra4.setProgress(0.01);

        }

    }

}
