package Controllers;

import ConexionBD.DBUtil;
import ConexionBD.ModeloRecetas;
import com.example.shotfood.Receta;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.*;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.List;
import java.util.Objects;

public class RecetasController {

    public Pane panePublicarRecetas;
    @FXML
    private Pane paneRecetas;

    @FXML
    private VBox contenedorResultados;

    @FXML
    private TextField fieldBuscador;

    private ModeloRecetas modeloRecetas = new ModeloRecetas();

    // Directorio donde se encuentran las imágenes (dentro del classpath)
    private final String IMAGES_DIR = "/images/";
    private final String DEFAULT_IMAGE = IMAGES_DIR + "default.png";

    public RecetasController() {
        // Constructor vacío
    }

    @FXML
    public void initialize() {
        // Verificar que la imagen por defecto esté disponible
        verificarImagenDefecto();

        fieldBuscador.setOnKeyPressed(event -> {
            if (event.getCode() == KeyCode.ENTER) {
                buscarReceta(null);
            }
        });

        // Cargar recetas al iniciar
        buscarReceta(null);
    }

    private void verificarImagenDefecto() {
        System.out.println("\n== VERIFICANDO UBICACIÓN DE IMAGEN POR DEFECTO ==");
        if (getClass().getResource(DEFAULT_IMAGE) != null) {
            System.out.println("✓ Imagen por defecto encontrada en: " + DEFAULT_IMAGE);
        } else {
            System.out.println("⚠ Imagen por defecto NO encontrada en: " + DEFAULT_IMAGE);
            System.out.println("Asegúrate de que existe el archivo en src/main/resources" + DEFAULT_IMAGE);
        }
    }

    @Deprecated
    public void toUsuario(ActionEvent actionEvent) throws IOException {
        Pane pane = FXMLLoader.load(getClass().getResource("/com/example/shotfood/Usuario.fxml"));
        this.paneRecetas.getChildren().setAll(pane);
    }

    @FXML
    public void Salir(ActionEvent actionEvent) throws IOException {
        AnchorPane pane = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("/com/example/shotfood/PantallaPrincipal.fxml")));
        this.paneRecetas.getChildren().setAll(pane);
    }

    @FXML
    public void buscarReceta(ActionEvent actionEvent) {
        String texto = fieldBuscador.getText() != null ? fieldBuscador.getText().trim() : "";

        List<Receta> resultados = modeloRecetas.buscarRecetas(texto);
        contenedorResultados.getChildren().clear();

        if (resultados.isEmpty()) {
            Text noResultados = new Text("No se encontraron recetas que coincidan con '" + texto + "'");
            noResultados.setStyle("-fx-font-size: 14px;");
            contenedorResultados.getChildren().add(noResultados);
            return;
        }

        for (Receta receta : resultados) {
            HBox tarjeta = new HBox(10);
            tarjeta.setMaxWidth(Region.USE_COMPUTED_SIZE);
            tarjeta.setPrefWidth(Region.USE_COMPUTED_SIZE);
            tarjeta.setPadding(new Insets(10));
            tarjeta.setStyle("-fx-background-color: white; -fx-border-color: lightgray; -fx-border-radius: 10; -fx-background-radius: 10;");
            // Imagen de la receta
            ImageView imagen = new ImageView();
            imagen.setFitWidth(100);
            imagen.setFitHeight(100);
            imagen.setPreserveRatio(true);

            // Cargar imagen con el método optimizado
            cargarImagen(imagen, receta);

            // Información de la receta
            VBox info = new VBox(5);
            Text titulo = new Text(receta.getNombre());
            titulo.setStyle("-fx-font-weight: bold; -fx-font-size: 16;");

            Text ingredientes = new Text("Ingredientes: " +
                    (receta.getIngredientes() != null && receta.getIngredientes().length() > 50 ?
                            receta.getIngredientes().substring(0, 50) + "..." :
                            receta.getIngredientes()));
            ingredientes.setStyle("-fx-font-style: italic;");

            Text resumen = new Text(receta.getTexto() != null && receta.getTexto().length() > 60 ?
                    receta.getTexto().substring(0, 60) + "..." :
                    receta.getTexto());

            Text duracion = new Text("Duración: " + receta.getDuracion() + " minutos");
            duracion.setStyle("-fx-font-size: 12;");

            info.getChildren().addAll(titulo, ingredientes, resumen, duracion);
            tarjeta.getChildren().addAll(imagen, info);

            tarjeta.setOnMouseClicked(event -> {
                mostrarDetallesReceta(receta);
            });

            contenedorResultados.getChildren().add(tarjeta);
        }
    }

    /**
     * Método optimizado para cargar imágenes
     * @param imageView El ImageView donde se mostrará la imagen
     * @param receta La receta que contiene la información de la imagen
     */
    private void cargarImagen(ImageView imageView, Receta receta) {
        boolean imagenCargada = false;
        String imagenPath = receta.getImagen();

        // 1. Verificar si tenemos un nombre de imagen
        if (imagenPath == null || imagenPath.trim().isEmpty()) {
            System.out.println("ℹ Receta sin ruta de imagen especificada, usando imagen por defecto");
            imagenPath = "default.png";
        }

        // 2. Preparar la ruta correcta para buscar como recurso
        String resourcePath = prepararRutaRecurso(imagenPath);
        System.out.println("ℹ Intentando cargar imagen desde: " + resourcePath);

        // 3. Intentar cargar la imagen como recurso (método preferido)
        try {
            InputStream is = getClass().getResourceAsStream(resourcePath);
            if (is != null) {
                Image img = new Image(is, 100, 100, true, true);
                if (!img.isError()) {
                    imageView.setImage(img);
                    imagenCargada = true;
                    System.out.println("✓ Imagen cargada correctamente como recurso: " + resourcePath);
                }
                is.close();
            } else {
                System.out.println("⚠ No se pudo obtener la imagen como recurso: " + resourcePath);
            }
        } catch (Exception e) {
            System.out.println("Error al cargar imagen como recurso: " + e.getMessage());
        }

        // 4. Si la imagen no se cargó, intentar con la imagen por defecto
        if (!imagenCargada) {
            try {
                InputStream is = getClass().getResourceAsStream(DEFAULT_IMAGE);
                if (is != null) {
                    Image img = new Image(is, 100, 100, true, true);
                    imageView.setImage(img);
                    imagenCargada = true;
                    System.out.println("✓ Usando imagen por defecto: " + DEFAULT_IMAGE);
                    is.close();
                } else {
                    System.out.println("⚠ No se pudo cargar ni siquiera la imagen por defecto");

                    // 5. Como último recurso, crear un rectángulo de color
                    imageView.setStyle("-fx-background-color: #ffcccc;");
                }
            } catch (Exception e) {
                System.out.println("Error al cargar imagen por defecto: " + e.getMessage());
            }
        }
    }

    /**
     * Prepara la ruta correcta para buscar la imagen como recurso
     */
    private String prepararRutaRecurso(String imagenPath) {
        // Si ya comienza con /, asumimos que es una ruta de recurso
        if (imagenPath.startsWith("/")) {
            return imagenPath;
        }

        // Si no contiene / ni \, asumimos que es solo un nombre de archivo
        if (!imagenPath.contains("/") && !imagenPath.contains("\\")) {
            return IMAGES_DIR + imagenPath;
        }

        // Si es una ruta completa, extraer solo el nombre del archivo
        String nombreArchivo = imagenPath;
        if (imagenPath.contains("/")) {
            nombreArchivo = imagenPath.substring(imagenPath.lastIndexOf("/") + 1);
        } else if (imagenPath.contains("\\")) {
            nombreArchivo = imagenPath.substring(imagenPath.lastIndexOf("\\") + 1);
        }

        return IMAGES_DIR + nombreArchivo;
    }

    private void mostrarDetallesReceta(Receta receta) {
        Stage ventana = new Stage();
        ventana.setTitle("Detalles de la receta");

        // Contenedor principal
        VBox contenedor = new VBox(10);
        contenedor.setPadding(new Insets(20));
        contenedor.setStyle("-fx-background-color: white;");

        // Título
        Label nombreLabel = new Label(receta.getNombre());
        nombreLabel.setFont(Font.font("Arial"));

        // Imagen
        ImageView imagenView = new ImageView();
        try {
            Image imagen = new Image(new File(receta.getImagen()).toURI().toString());
            imagenView.setImage(imagen);
            imagenView.setFitHeight(200);
            imagenView.setFitWidth(300);
            imagenView.setPreserveRatio(true);
        } catch (Exception e) {
            System.out.println("Error cargando imagen: " + e.getMessage());
        }

        // Ingredientes
        Label ingredientesLabel = new Label("Ingredientes:");
        ingredientesLabel.setFont(Font.font("Arial"));
        TextArea ingredientesArea = new TextArea(receta.getIngredientes());
        ingredientesArea.setWrapText(true);
        ingredientesArea.setEditable(false);
        ingredientesArea.setPrefRowCount(3);

        // Descripción
        Label descripcionLabel = new Label("Descripción:");
        descripcionLabel.setFont(Font.font("Arial"));
        TextArea descripcionArea = new TextArea(receta.getTexto());
        descripcionArea.setWrapText(true);
        descripcionArea.setEditable(false);
        descripcionArea.setPrefRowCount(4);

        // Otros datos
        Label duracion = new Label("Duración: " + receta.getDuracion() + " minutos");
        Label fecha = new Label("Fecha: " + receta.getFecha_creacion());

        // Añadir al contenedor
        contenedor.getChildren().addAll(
                nombreLabel, imagenView,
                ingredientesLabel, ingredientesArea,
                descripcionLabel, descripcionArea,
                duracion, fecha
        );

        // Mostrar en nueva escena
        Scene escena = new Scene(contenedor, 400, 600);
        ventana.setScene(escena);
        ventana.show();
    }


    @FXML
    public void irPublicaciones(ActionEvent actionEvent) throws IOException {

        Pane pane = FXMLLoader.load(getClass().getResource("/com/example/shotfood/PublicarRecetas.fxml"));
        this.paneRecetas.getChildren().setAll(pane);

    }
}