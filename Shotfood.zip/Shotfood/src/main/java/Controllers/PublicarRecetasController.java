package Controllers;


import ConexionBD.PublicacionModel;
import com.example.shotfood.Publicacion;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.*;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;

import java.io.IOException;
import java.util.List;

public class PublicarRecetasController {

    @FXML
    public Pane panePublicarRecetas;
    @FXML
    private TextField FieldUsuario;

    @FXML
    private VBox comentariosBox;
    @FXML
    private TextArea comentarioInput;

    private final int recetaActualId = 1; // Simulado. Puedes cargarlo dinámicamente.

    @FXML
    public void initialize() {
        cargarPublicaciones();
    }

    @Deprecated
    public void toPublicar(ActionEvent actionEvent) throws IOException {
        Pane pane = FXMLLoader.load(getClass().getResource("/com/example/shotfood/RecetasController.fxml"));
        this.panePublicarRecetas.getChildren().setAll(pane);
    }

    private void cargarPublicaciones() {
        comentariosBox.getChildren().clear();
        List<Publicacion> publicaciones = PublicacionModel.obtenerPublicacionesPorReceta(recetaActualId);

        for (Publicacion pub : publicaciones) {
            Label label = new Label(pub.getUsuario() + " (" + pub.getFecha() + "):\n" + pub.getTexto());
            label.setStyle("-fx-background-color: #f0f0f0; -fx-padding: 10; -fx-background-radius: 10;");
            comentariosBox.getChildren().add(label);
        }
    }

    @FXML
    private void publicarComentario() {
        String texto = comentarioInput.getText().trim();
        String usuario = FieldUsuario.getText(); // Tomamos el usuario desde el campo

        if (!texto.isEmpty() && !usuario.isEmpty()) {
            PublicacionModel.insertarPublicacion(new Publicacion(0, recetaActualId, usuario, texto, null));
            comentarioInput.clear();
            cargarPublicaciones();
        }
    }
}