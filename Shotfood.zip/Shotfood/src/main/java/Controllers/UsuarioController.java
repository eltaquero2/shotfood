package Controllers;

import com.example.shotfood.Usuario;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.FileChooser;
import java.io.File;
import java.io.FileInputStream;
import javafx.scene.shape.Circle;


import java.io.IOException;

public class UsuarioController {
    @javafx.fxml.FXML
    private Label nombreUsuario;
    @javafx.fxml.FXML
    private Pane UsuarioPane;
    @FXML
    private Label labelcontraseña;
    @FXML
    private Button CambiarFoto;
    @FXML
    private ImageView fotoPerfil;
    @FXML
    private ImageView imagenAdmin;


    @Deprecated
    public void Salir(ActionEvent actionEvent) throws IOException {
        Pane pane = FXMLLoader.load(getClass().getResource("/com/example/shotfood/PantallaPrincipal.fxml"));
        this.UsuarioPane.getChildren().setAll(pane);
    }

    @javafx.fxml.FXML
    public void CerrarSesion(ActionEvent actionEvent) throws IOException{
        Pane pane = FXMLLoader.load(getClass().getResource("/com/example/shotfood/InicioSesion.fxml"));
        this.UsuarioPane.getChildren().setAll(pane);
    }

    @javafx.fxml.FXML
    public void Ayuda(ActionEvent actionEvent) {
        try {
            java.awt.Desktop.getDesktop().browse(new java.net.URI("https://raspberrypi.tailbc17ce.ts.net"));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @javafx.fxml.FXML
    public void Seguridad(ActionEvent actionEvent) {
    }

    @javafx.fxml.FXML
    public void ver_ocultar(ActionEvent actionEvent) {
        Usuario usuario = Usuario.getUsuarioActual();
        String contra_oculta = "";
        for(int i = 0; i < usuario.getContraseña().length(); i++){
            contra_oculta += "*";
        }

        String texto_label = labelcontraseña.getText();

        if(texto_label.equals(contra_oculta)) {
            labelcontraseña.setText(usuario.getContraseña());
        }
        if(texto_label.equals(usuario.getContraseña())){
            labelcontraseña.setText(contra_oculta);
        }
    }

    @FXML
    public void initialize() {
        Usuario usuario = Usuario.getUsuarioActual();
        String contra_oculta = "";

        for(int i = 0; i < usuario.getContraseña().length(); i++){
            contra_oculta += "*";
        }

        if(usuario != null && nombreUsuario != null) {
            nombreUsuario.setText(usuario.getNombre());
            labelcontraseña.setText(contra_oculta);

            if (usuario.isAdmin()) {
                imagenAdmin.setOpacity(1.0);
            } else {
                imagenAdmin.setOpacity(0.0);
            }
        }

        // Clip circular centrado en un ImageView de 150x150
        Circle clip = new Circle(75, 75, 75); // centro x=75, y=75, radio=75
        fotoPerfil.setFitWidth(150);
        fotoPerfil.setFitHeight(150);
        fotoPerfil.setClip(clip);
    }

    @FXML
    public void cargarImagenDesdePC(ActionEvent actionEvent) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Seleccionar Imagen de Perfil");
        fileChooser.getExtensionFilters().addAll(
                new FileChooser.ExtensionFilter("Imágenes", "*.png", "*.jpg", "*.jpeg")
        );
        File file = fileChooser.showOpenDialog(null);
        if (file != null) {
            Image image = new Image(file.toURI().toString());
            fotoPerfil.setImage(image);
        }
    }

    @Deprecated
    public void seleccionarImagen(ActionEvent actionEvent) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Seleccionar Imagen de Perfil");
        fileChooser.getExtensionFilters().addAll(
                new FileChooser.ExtensionFilter("Imágenes", "*.png", "*.jpg", "*.jpeg", "*.gif")
        );
        File archivoSeleccionado = fileChooser.showOpenDialog(null);

        if (archivoSeleccionado != null) {
            try {
                FileInputStream input = new FileInputStream(archivoSeleccionado);
                Image imagen = new Image(input);
                fotoPerfil.setImage(imagen);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    @FXML
    public void GoBack(ActionEvent actionEvent) {
    }
}
