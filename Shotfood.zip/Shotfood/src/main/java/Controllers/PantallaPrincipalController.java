package Controllers;

import com.example.shotfood.Usuario;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;

import java.io.IOException;

public class PantallaPrincipalController {
    @javafx.fxml.FXML
    private AnchorPane PanePrincipal;

    @javafx.fxml.FXML
    public void toRegistro(ActionEvent actionEvent) throws IOException {

        Pane pane = FXMLLoader.load(getClass().getResource("/com/example/shotfood/Registro.fxml"));
        this.PanePrincipal.getChildren().setAll(pane);

    }

    @javafx.fxml.FXML
    public void toRecetas(ActionEvent actionEvent) throws IOException {
        Usuario usuario = Usuario.getUsuarioActual();

        if (usuario.isAdmin()) {
            Pane pane = FXMLLoader.load(getClass().getResource("/com/example/shotfood/RecetasAdmin.fxml"));
            this.PanePrincipal.getChildren().setAll(pane);

        } else {
           Pane pane = FXMLLoader.load(getClass().getResource("/com/example/shotfood/Recetas.fxml"));
           this.PanePrincipal.getChildren().setAll(pane);
        }


    }

    @javafx.fxml.FXML
    public void toDietas(ActionEvent actionEvent) throws IOException {

        Pane pane = FXMLLoader.load(getClass().getResource("/com/example/shotfood/Dietas.fxml"));
        this.PanePrincipal.getChildren().setAll(pane);

    }

    @javafx.fxml.FXML
    public void toUsuario(ActionEvent actionEvent) throws IOException {

        Pane pane = FXMLLoader.load(getClass().getResource("/com/example/shotfood/Usuario.fxml"));
        this.PanePrincipal.getChildren().setAll(pane);

    }
}
