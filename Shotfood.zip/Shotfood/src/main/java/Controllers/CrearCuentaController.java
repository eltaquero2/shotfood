package Controllers;

import ConexionBD.UsuarioModel;
import com.example.shotfood.Usuario;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;

import java.io.IOException;

public class CrearCuentaController {
    @javafx.fxml.FXML
    private PasswordField ConfirmarContraseñaField;
    @javafx.fxml.FXML
    private PasswordField ContraseñaField;
    @javafx.fxml.FXML
    private TextField UsuarioField;
    @javafx.fxml.FXML
    private Label errorLabel;
    @javafx.fxml.FXML
    private AnchorPane PaneCrearCuenta;

    @javafx.fxml.FXML
    public void CrearCuenta(ActionEvent actionEvent) throws IOException {
        String nombreUsr = UsuarioField.getText();
        String contraseñaUsr = ContraseñaField.getText();
        String confirmarContraseña = ConfirmarContraseñaField.getText();

        UsuarioModel um = new UsuarioModel();

        if(contraseñaUsr.equals(confirmarContraseña)){

            Usuario u = new Usuario(nombreUsr, contraseñaUsr);

            um.crearCuenta(u);

            Alert alerta = new Alert(Alert.AlertType.INFORMATION);
            alerta.setTitle("Cuenta creada");
            alerta.setHeaderText(null);
            alerta.setContentText("¡La cuenta fue creada exitosamente!");

            alerta.showAndWait();

            Pane pane = FXMLLoader.load(getClass().getResource("/com/example/shotfood/InicioSesion.fxml"));
            this.PaneCrearCuenta.getChildren().setAll(pane);
        } else {
            errorLabel.setText("Las contraseñas no coinciden");
        }
    }

    @javafx.fxml.FXML
    public void ToIniciarSesion(ActionEvent actionEvent) throws IOException {

        Pane pane = FXMLLoader.load(getClass().getResource("/com/example/shotfood/InicioSesion.fxml"));
        this.PaneCrearCuenta.getChildren().setAll(pane);

    }
}
