package Controllers;

import ConexionBD.NutrientesModel;
import com.example.shotfood.Nutrientes;
import com.example.shotfood.Usuario;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.layout.AnchorPane;

import java.io.IOException;
import java.net.URL;
import java.util.Objects;
import java.util.ResourceBundle;
import javafx.scene.layout.Pane;

public class EditarNutrientesController implements Initializable {
    @FXML
    private Pane paneEditarNutrientes;
    @FXML
    private ComboBox<String> comboB1;
    @FXML
    private ComboBox<String> comboB2;
    @FXML
    private ComboBox<String> comboB3;
    @FXML
    private ComboBox<String> comboB4;
    @FXML
    private Spinner<Integer> objetivo1;
    @FXML
    private Spinner<Integer> objetivo2;
    @FXML
    private Spinner<Integer> objetivo3;
    @FXML
    private Spinner<Integer> objetivo4;
    @FXML
    private Label errorLabel;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        NutrientesModel nm = new NutrientesModel();

        for (Nutrientes t : nm.getNutrientes()) {
            comboB1.getItems().add(t.getNombre());
            comboB2.getItems().add(t.getNombre());
            comboB3.getItems().add(t.getNombre());
            comboB4.getItems().add(t.getNombre());
        }

        objetivo1.setValueFactory(new SpinnerValueFactory.IntegerSpinnerValueFactory(0, 1500, 0));
        objetivo2.setValueFactory(new SpinnerValueFactory.IntegerSpinnerValueFactory(0, 1500, 0));
        objetivo3.setValueFactory(new SpinnerValueFactory.IntegerSpinnerValueFactory(0, 1500, 0));
        objetivo4.setValueFactory(new SpinnerValueFactory.IntegerSpinnerValueFactory(0, 1500, 0));

        objetivo1.setEditable(true);
        objetivo2.setEditable(true);
        objetivo3.setEditable(true);
        objetivo4.setEditable(true);

        comboB1.setStyle(
                "-fx-font-size: 14px;" +
                        "-fx-font-family: 'Segoe UI';" +
                        "-fx-background-color: #ffe5e5;" +
                        "-fx-border-color: #ccc;" +
                        "-fx-border-radius: 8;" +
                        "-fx-background-radius: 8;" +
                        "-fx-padding: 6 12;" +
                        "-fx-effect: dropshadow(one-pass-box, rgba(0,0,0,0.05), 1, 0, 0, 1);"
        );

        comboB2.setStyle(
                "-fx-font-size: 14px;" +
                        "-fx-font-family: 'Segoe UI';" +
                        "-fx-background-color: #fff9db;" +
                        "-fx-border-color: #ccc;" +
                        "-fx-border-radius: 8;" +
                        "-fx-background-radius: 8;" +
                        "-fx-padding: 6 12;" +
                        "-fx-effect: dropshadow(one-pass-box, rgba(0,0,0,0.05), 1, 0, 0, 1);"
        );

        comboB3.setStyle(
                "-fx-font-size: 14px;" +
                        "-fx-font-family: 'Segoe UI';" +
                        "-fx-background-color: #e0f0ff;" +
                        "-fx-border-color: #ccc;" +
                        "-fx-border-radius: 8;" +
                        "-fx-background-radius: 8;" +
                        "-fx-padding: 6 12;" +
                        "-fx-effect: dropshadow(one-pass-box, rgba(0,0,0,0.05), 1, 0, 0, 1);"
        );

        comboB4.setStyle(
                "-fx-font-size: 14px;" +
                        "-fx-font-family: 'Segoe UI';" +
                        "-fx-background-color: #fbe8ff;" +
                        "-fx-border-color: #ccc;" +
                        "-fx-border-radius: 8;" +
                        "-fx-background-radius: 8;" +
                        "-fx-padding: 6 12;" +
                        "-fx-effect: dropshadow(one-pass-box, rgba(0,0,0,0.05), 1, 0, 0, 1);"
        );

        objetivo1.setStyle(
                "-fx-font-size: 14px;" +
                        "-fx-font-family: 'Segoe UI';" +
                        "-fx-background-color: white;" +
                        "-fx-background-color: white;" +
                        "-fx-border-radius: 8;" +
                        "-fx-background-radius: 8;" +
                        "-fx-padding: 6;" +
                        "-fx-effect: dropshadow(one-pass-box, rgba(0,0,0,0.05), 1, 0, 0, 1);"
        );

        objetivo2.setStyle(
                "-fx-font-size: 14px;" +
                        "-fx-font-family: 'Segoe UI';" +
                        "-fx-background-color: white;" +
                        "-fx-border-color: #ccc;" +
                        "-fx-border-radius: 8;" +
                        "-fx-background-radius: 8;" +
                        "-fx-padding: 6;" +
                        "-fx-effect: dropshadow(one-pass-box, rgba(0,0,0,0.05), 1, 0, 0, 1);"
        );

        objetivo3.setStyle(
                "-fx-font-size: 14px;" +
                        "-fx-font-family: 'Segoe UI';" +
                        "-fx-background-color: white;" +
                        "-fx-border-color: #ccc;" +
                        "-fx-border-radius: 8;" +
                        "-fx-background-radius: 8;" +
                        "-fx-padding: 6;" +
                        "-fx-effect: dropshadow(one-pass-box, rgba(0,0,0,0.05), 1, 0, 0, 1);"
        );

        objetivo4.setStyle(
                "-fx-font-size: 14px;" +
                        "-fx-font-family: 'Segoe UI';" +
                        "-fx-background-color: white;" +
                        "-fx-border-color: #ccc;" +
                        "-fx-border-radius: 8;" +
                        "-fx-background-radius: 8;" +
                        "-fx-padding: 6;" +
                        "-fx-effect: dropshadow(one-pass-box, rgba(0,0,0,0.05), 1, 0, 0, 1);"
        );

    }

    @FXML
    public void Aplicate(ActionEvent actionEvent) {
        try {
            Usuario usuario = Usuario.getUsuarioActual();
            NutrientesModel nm = new NutrientesModel();

            String nombre1 = comboB1.getValue();
            String nombre2 = comboB2.getValue();
            String nombre3 = comboB3.getValue();
            String nombre4 = comboB4.getValue();

            Nutrientes n1 = getNutrientePorNombre(nombre1);
            Nutrientes n2 = getNutrientePorNombre(nombre2);
            Nutrientes n3 = getNutrientePorNombre(nombre3);
            Nutrientes n4 = getNutrientePorNombre(nombre4);

            if (n1 == null || n2 == null || n3 == null || n4 == null) {
                errorLabel.setText("Selecciona todos los nutrientes");
                return;
            }

            nm.asignarObjetivo(usuario.getId(), n1.getId(), objetivo1.getValue());
            nm.asignarObjetivo(usuario.getId(), n2.getId(), objetivo2.getValue());
            nm.asignarObjetivo(usuario.getId(), n3.getId(), objetivo3.getValue());
            nm.asignarObjetivo(usuario.getId(), n4.getId(), objetivo4.getValue());

            Alert alerta = new Alert(Alert.AlertType.INFORMATION);
            alerta.setTitle("Añadido correctamente");
            alerta.setHeaderText(null);
            alerta.setContentText("¡Los Nutrientes y sus objetvios han sido añadidos!");

            alerta.showAndWait();

        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
            errorLabel.setText("Inserta todos los datos correctamente");
        }
    }

    @FXML
    public void GoBack(ActionEvent actionEvent) throws IOException {
        Pane pane = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("/com/example/shotfood/Registro.fxml")));
        this.paneEditarNutrientes.getChildren().setAll(pane);
    }

    private Nutrientes getNutrientePorNombre(String nombre) {
        NutrientesModel nm = new NutrientesModel();
        for (Nutrientes n : nm.getNutrientes()) {
            if (n.getNombre().equals(nombre)) {
                return n;
            }
        }
        return null;
    }

    public int idNutriente1(){
        String nombre1 = comboB1.getValue();
        Nutrientes n1 = getNutrientePorNombre(nombre1);
        return n1.getId();
    }

    public int idNutriente2(){
        String nombre2 = comboB2.getValue();
        Nutrientes n2 = getNutrientePorNombre(nombre2);
        return n2.getId();
    }

    public int idNutriente3(){
        String nombre3 = comboB3.getValue();
        Nutrientes n3 = getNutrientePorNombre(nombre3);
        return n3.getId();
    }

    public int idNutriente4(){
        String nombre4 = comboB4.getValue();
        Nutrientes n4 = getNutrientePorNombre(nombre4);
        return n4.getId();
    }

}
