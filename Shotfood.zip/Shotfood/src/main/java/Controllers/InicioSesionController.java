package Controllers;

import ConexionBD.UsuarioModel;
import com.example.shotfood.HelloApplication;
import com.example.shotfood.Usuario;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;

import java.io.IOException;
import java.util.Objects;

public class InicioSesionController {

    @FXML
    private TextField FieldUsuario;
    @FXML
    private Label labelError;
    @FXML
    private AnchorPane PaneInicioSesion;
    @FXML
    private PasswordField FieldContraseña;

    @FXML
    public void ToCrearCuenta(ActionEvent actionEvent) throws IOException {

        AnchorPane pane = FXMLLoader.load(getClass().getResource("/com/example/shotfood/CrearCuenta.fxml"));
        this.PaneInicioSesion.getChildren().setAll(pane);

    }

    @FXML
    public void IniciarSesion(ActionEvent actionEvent) throws IOException {
        String nombreUsr = FieldUsuario.getText();
        String contraseñaUsr = FieldContraseña.getText();


        UsuarioModel um = new UsuarioModel();

        if(um.verificarCredenciales(nombreUsr, contraseñaUsr)){

            try {
                Usuario usuario = new Usuario(nombreUsr, contraseñaUsr);
                Usuario.setUsuarioActual(usuario);

                AnchorPane pane = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("/com/example/shotfood/PantallaPrincipal.fxml")));
                this.PaneInicioSesion.getChildren().setAll(pane);

            } catch (Exception e) {
                System.out.println(e.getMessage());
                throw new RuntimeException(e);

            }
        } else {
            labelError.setText("Contraseña o usuario incorrecto");
        }
    }
}
