package ConexionBD;

import com.example.shotfood.Dieta;
import com.example.shotfood.Tipo;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class DietaModel extends DBUtil {

    public ArrayList<Dieta> getDietas() {

        ArrayList<Dieta> listaDietas = new ArrayList<Dieta>();

        try {
            //Iniciamos conexi�n
            String sql = "SELECT id, id_tipo, nombre FROM dietas";
            PreparedStatement stmt = this.getConexion().prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();

            while(rs.next()) {

                int id = rs.getInt("id");
                int tipo = rs.getInt("id_tipo");
                String nombre = rs.getString("nombre");

                Dieta d = new Dieta(id, tipo, nombre);
                listaDietas.add(d);
            }

            return listaDietas;

        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
        finally {
            //Cerramos conexi�n
            this.cerrarConexion();
        }
    }

}
