package ConexionBD;

import com.example.shotfood.Receta;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.nio.file.Paths;
import java.nio.file.Path;

public class ModeloRecetas extends DBUtil {
    private DBUtil dbUtil;

    public ModeloRecetas() {
        this.dbUtil = new DBUtil();
    }

    public List<Receta> obtenerTodasLasRecetas() {
        List<Receta> resultados = new ArrayList<>();
        String sql = "SELECT * FROM Recetas";

        try (PreparedStatement stmt = getConexion().prepareStatement(sql)) {
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                Receta receta = new Receta(
                        rs.getInt("id"),
                        rs.getString("Nombre"),
                        rs.getString("Ingredientes"),
                        rs.getString("Texto"),
                        rs.getString("Fecha_Creacion"),
                        rs.getInt("Duracion"),
                        rs.getString("Imagen")
                );
                resultados.add(receta);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Error al obtener todas las recetas: " + e.getMessage());
        }

        return resultados;
    }

    public void insertarReceta(Receta receta) {
        // Procesar la ruta de la imagen antes de guardarla
        String rutaImagen = normalizarRutaImagen(receta.getImagen());

        String sql = "INSERT INTO Recetas (Nombre, Ingredientes, Texto, Fecha_Creacion, Duracion, Imagen) VALUES (?, ?, ?, ?, ?, ?)";
        try (PreparedStatement stmt = getConexion().prepareStatement(sql)) {
            stmt.setString(1, receta.getNombre());
            stmt.setString(2, receta.getIngredientes());
            stmt.setString(3, receta.getTexto());

            try {
                stmt.setDate(4, Date.valueOf(receta.getFecha_creacion()));
            } catch (Exception e) {
                stmt.setDate(4, new Date(System.currentTimeMillis()));
                System.out.println("Error en formato de fecha, usando fecha actual: " + e.getMessage());
            }

            stmt.setInt(5, receta.getDuracion());
            stmt.setString(6, rutaImagen);

            stmt.executeUpdate();
            System.out.println("Receta insertada correctamente con imagen: " + rutaImagen);
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Error SQL al insertar receta: " + e.getMessage());
        }
    }

    public void actualizarReceta(Receta receta) {
        // Procesar la ruta de la imagen antes de guardarla
        String rutaImagen = normalizarRutaImagen(receta.getImagen());

        String sql = "UPDATE Recetas SET Nombre = ?, Ingredientes = ?, Texto = ?, Fecha_Creacion = ?, Duracion = ?, Imagen = ? WHERE id = ?";
        try (PreparedStatement stmt = getConexion().prepareStatement(sql)) {
            stmt.setString(1, receta.getNombre());
            stmt.setString(2, receta.getIngredientes());
            stmt.setString(3, receta.getTexto());

            try {
                stmt.setDate(4, Date.valueOf(receta.getFecha_creacion()));
            } catch (Exception e) {
                stmt.setDate(4, new Date(System.currentTimeMillis()));
            }

            stmt.setInt(5, receta.getDuracion());
            stmt.setString(6, rutaImagen);
            stmt.setInt(7, receta.getId());

            int filas = stmt.executeUpdate();
            if (filas > 0) {
                System.out.println("Receta actualizada correctamente con imagen: " + rutaImagen);
            } else {
                System.out.println("No se encontró ninguna receta con ese ID: " + receta.getId());
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /**
     * Normaliza la ruta de la imagen para guardarla en la base de datos.
     * Extrae solo el nombre del archivo de una ruta absoluta o relativa.
     */
    private String normalizarRutaImagen(String rutaImagen) {
        if (rutaImagen == null || rutaImagen.trim().isEmpty()) {
            return "default.png"; // Imagen por defecto
        }

        // Si la ruta ya es un nombre de archivo sin ruta, devolverla
        if (!rutaImagen.contains("/") && !rutaImagen.contains("\\")) {
            return rutaImagen;
        }

        // Extraer el nombre del archivo de la ruta completa
        Path path = Paths.get(rutaImagen);
        String nombreArchivo = path.getFileName().toString();

        return nombreArchivo;
    }

    public void eliminarReceta(int id) {
        String sql = "DELETE FROM Recetas WHERE id = ?";
        try (PreparedStatement stmt = getConexion().prepareStatement(sql)) {
            stmt.setInt(1, id);
            int filas = stmt.executeUpdate();
            if (filas > 0) {
                System.out.println("Receta eliminada correctamente: ID " + id);
            } else {
                System.out.println("No se encontró ninguna receta con ese ID: " + id);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public Receta obtenerRecetaPorId(int id) {
        String sql = "SELECT * FROM Recetas WHERE id = ?";
        try (PreparedStatement stmt = getConexion().prepareStatement(sql)) {
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                return new Receta(
                        rs.getInt("id"),
                        rs.getString("Nombre"),
                        rs.getString("Ingredientes"),
                        rs.getString("Texto"),
                        rs.getString("Fecha_Creacion"),
                        rs.getInt("Duracion"),
                        rs.getString("Imagen")
                );
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public List<Receta> buscarRecetas(String filtro) {
        List<Receta> resultados = new ArrayList<>();

        if (filtro == null || filtro.trim().isEmpty()) {
            return obtenerTodasLasRecetas();
        }

        String sql = "SELECT * FROM Recetas WHERE nombre LIKE ? OR ingredientes LIKE ?";

        try (PreparedStatement stmt = getConexion().prepareStatement(sql)) {
            stmt.setString(1, "%" + filtro + "%");
            stmt.setString(2, "%" + filtro + "%");

            System.out.println("Ejecutando SQL: " + sql.replace("?", "'" + "%" + filtro + "%" + "'"));
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                String imagen = rs.getString("Imagen");

                Receta receta = new Receta(
                        rs.getInt("id"),
                        rs.getString("Nombre"),
                        rs.getString("Ingredientes"),
                        rs.getString("Texto"),
                        rs.getString("Fecha_Creacion"),
                        rs.getInt("Duracion"),
                        imagen
                );
                resultados.add(receta);
                System.out.println("Receta encontrada: " + receta.getNombre() +
                        ", ID: " + receta.getId() +
                        ", Imagen: " + (imagen != null ? imagen : "No disponible"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Error en la consulta SQL: " + e.getMessage());
        }

        System.out.println("Total de recetas encontradas: " + resultados.size());
        return resultados;
    }

    public boolean eliminarRecetaPorId(int id) {
        Connection conn = dbUtil.getConexion();
        String sql = "DELETE FROM recetas WHERE id = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            int rows = stmt.executeUpdate();
            return rows > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } finally {
            dbUtil.cerrarConexion();
        }
    }
}
