package ConexionBD;

import com.example.shotfood.Dieta;
import com.example.shotfood.Publicacion;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class PublicacionModel extends DBUtil {

    private static final String DB_URL = "jdbc:mysql://localhost:3306/shotfood";
    private static final String USER = "root";
    private static final String PASS = "tu_contraseña"; // Cambia esto por tu contraseña real

    public static List<Publicacion> obtenerPublicacionesPorReceta(int recetaId) {
        List<Publicacion> lista = new ArrayList<>();
        String query = "SELECT * FROM comentarios WHERE receta_id = ? ORDER BY fecha DESC";

        try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setInt(1, recetaId);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                Publicacion p = new Publicacion(
                        rs.getInt("id"),
                        rs.getInt("receta_id"),
                        rs.getString("usuario"),
                        rs.getString("comentario"),
                        rs.getString("fecha")
                );
                lista.add(p);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return lista;
    }

    public static void insertarPublicacion(Publicacion publicacion) {
        String insert = "INSERT INTO comentarios (receta_id, usuario, comentario) VALUES (?, ?, ?)";

        try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
             PreparedStatement stmt = conn.prepareStatement(insert)) {

            stmt.setInt(1, publicacion.getRecetaId());
            stmt.setString(2, publicacion.getUsuario());
            stmt.setString(3, publicacion.getTexto());
            stmt.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}