package ConexionBD;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.UUID;

/**
 * Utilidad para manejar la carga y gestión de imágenes
 */
public class ImagenUtil {

    // Directorio de recursos para imágenes
    private static final String RESOURCES_DIR = "src/main/resources";
    private static final String IMAGES_DIR = RESOURCES_DIR + "/images";
    private static final String DEFAULT_IMAGE = "default.png";

    /**
     * Copia una imagen externa al directorio de recursos y devuelve el nombre del archivo
     * @param rutaOriginal Ruta original del archivo de imagen
     * @return Nombre del archivo guardado
     */
    public static String guardarImagen(String rutaOriginal) {
        if (rutaOriginal == null || rutaOriginal.trim().isEmpty()) {
            return DEFAULT_IMAGE;
        }

        try {
            // Verificar que el directorio de imágenes existe
            File directorioImagenes = new File(IMAGES_DIR);
            if (!directorioImagenes.exists()) {
                directorioImagenes.mkdirs();
            }

            // Abrir el archivo original
            File archivoOriginal = new File(rutaOriginal);
            if (!archivoOriginal.exists() || !archivoOriginal.isFile()) {
                System.out.println("El archivo original no existe: " + rutaOriginal);
                return DEFAULT_IMAGE;
            }

            // Generar un nombre único para evitar colisiones
            String extension = obtenerExtension(rutaOriginal);
            String nombreArchivo = UUID.randomUUID().toString() + extension;
            File archivoDestino = new File(IMAGES_DIR + File.separator + nombreArchivo);

            // Copiar el archivo
            Files.copy(
                    archivoOriginal.toPath(),
                    archivoDestino.toPath(),
                    StandardCopyOption.REPLACE_EXISTING
            );

            System.out.println("Imagen copiada correctamente a: " + archivoDestino.getPath());
            return nombreArchivo;

        } catch (IOException e) {
            System.out.println("Error al guardar la imagen: " + e.getMessage());
            e.printStackTrace();
            return DEFAULT_IMAGE;
        }
    }

    /**
     * Devuelve la extensión de un archivo incluido el punto (ej: .jpg)
     */
    private static String obtenerExtension(String rutaArchivo) {
        int i = rutaArchivo.lastIndexOf('.');
        if (i > 0) {
            return rutaArchivo.substring(i);
        }
        return ".png"; // Extensión por defecto
    }

    /**
     * Obtiene la ruta de recurso a partir del nombre del archivo
     */
    public static String obtenerRutaRecurso(String nombreArchivo) {
        if (nombreArchivo == null || nombreArchivo.trim().isEmpty()) {
            return "/images/" + DEFAULT_IMAGE;
        }

        // Si ya es una ruta de recurso completa, devolverla
        if (nombreArchivo.startsWith("/")) {
            return nombreArchivo;
        }

        // Si contiene separadores de directorios, extraer solo el nombre
        if (nombreArchivo.contains("/") || nombreArchivo.contains("\\")) {
            Path path = Paths.get(nombreArchivo);
            nombreArchivo = path.getFileName().toString();
        }

        return "/images/" + nombreArchivo;
    }

    /**
     * Verifica si una imagen existe en el directorio de recursos
     * @param nombreArchivo Nombre del archivo a verificar
     * @return true si existe
     */
    public static boolean existeImagen(String nombreArchivo) {
        if (nombreArchivo == null || nombreArchivo.trim().isEmpty()) {
            return false;
        }

        // Extraer solo el nombre si es una ruta completa
        if (nombreArchivo.contains("/") || nombreArchivo.contains("\\")) {
            Path path = Paths.get(nombreArchivo);
            nombreArchivo = path.getFileName().toString();
        }

        // Verificar si existe en el directorio de recursos
        try (InputStream is = ImagenUtil.class.getResourceAsStream("/images/" + nombreArchivo)) {
            return is != null;
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Elimina una imagen del directorio de recursos
     * @param nombreArchivo El nombre del archivo a eliminar
     * @return true si se eliminó correctamente
     */
    public static boolean eliminarImagen(String nombreArchivo) {
        if (nombreArchivo == null || nombreArchivo.trim().isEmpty() ||
                nombreArchivo.equals(DEFAULT_IMAGE)) {
            return false; // No eliminar la imagen por defecto
        }

        try {
            File archivo = new File(IMAGES_DIR + File.separator + nombreArchivo);
            if (archivo.exists() && archivo.isFile()) {
                return archivo.delete();
            }
            return false;
        } catch (Exception e) {
            System.out.println("Error al eliminar la imagen: " + e.getMessage());
            return false;
        }
    }
}