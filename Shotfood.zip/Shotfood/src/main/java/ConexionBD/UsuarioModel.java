package ConexionBD;

import com.example.shotfood.Usuario;

import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.embed.swing.SwingFXUtils;


import javax.imageio.ImageIO;
import java.io.ByteArrayOutputStream;
import java.sql.DriverManager;


public class UsuarioModel extends DBUtil {

    public ArrayList<Usuario> getUsuario() {

        ArrayList<Usuario> listaUsuario = new ArrayList<Usuario>();

        try {
            // Iniciamos conexión
            String sql = "SELECT id, nombre, contrasea, admin FROM usuario";
            PreparedStatement stmt = this.getConexion().prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                int id = rs.getInt("id");
                String nombre = rs.getString("nombre");
                String contraseña = rs.getString("contrasea");
                boolean admin = rs.getBoolean("admin");

                Usuario u = new Usuario(id, nombre, contraseña, admin);
                listaUsuario.add(u);
            }

            return listaUsuario;

        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        } finally {
            this.cerrarConexion();
        }
    }

    public boolean verificarCredenciales(String nombreUsuario, String contrasena) {
        String sql = "SELECT * FROM usuario WHERE nombre = ? AND contrasea = ?";

        try (PreparedStatement stmt = this.getConexion().prepareStatement(sql)) {
            stmt.setString(1, nombreUsuario);
            stmt.setString(2, contrasena);

            ResultSet resultado = stmt.executeQuery();

            return resultado.next(); // Devuelve true si hay coincidencia
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean crearCuenta(Usuario u){
        String sql = "INSERT INTO usuario (nombre, contrasea) VALUES (?, ?)";

        try (PreparedStatement stmt = this.getConexion().prepareStatement(sql)) {
            stmt.setString(1, u.getNombre());
            stmt.setString(2, u.getContraseña());

            stmt.execute();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // En UsuarioModel.java
    public Usuario obtenerUsuario(String nombre, String contraseña) {
        Connection conn = getConexion();
        Usuario usuario = null;

        String sql = "SELECT id, nombre, contrasea, admin FROM usuario WHERE nombre = ? AND contrasea = ?";

        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, nombre);
            stmt.setString(2, contraseña);

            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                int id = rs.getInt("id");
                String nombreBD = rs.getString("nombre");
                String contraseñaBD = rs.getString("contraseña");
                boolean esAdmin = rs.getBoolean("admin");

                usuario = new Usuario(id, nombreBD, contraseñaBD, esAdmin);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            cerrarConexion();
        }

        return usuario;
    }

    public void guardarImagenEnBD(ImageView imageView, int idUsuario) {
        try {
            // Obtener la imagen del ImageView
            Image image = imageView.getImage();

            // Convertir a BufferedImage
            BufferedImage bufferedImage = SwingFXUtils.fromFXImage(image, null);

            // Escribir en un ByteArrayOutputStream
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            ImageIO.write(bufferedImage, "png", baos);
            byte[] imageBytes = baos.toByteArray();


            // Usar UPDATE si el usuario ya existe
            String sql = "UPDATE usuario SET imagen = ? WHERE id = ?";
            PreparedStatement pstmt = this.getConexion().prepareStatement(sql);
            pstmt.setBytes(1, imageBytes);
            pstmt.setInt(2, idUsuario);

            pstmt.executeUpdate();
            pstmt.close();
            this.getConexion().close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void cargarImagenDesdeBD(ImageView imageView, int idUsuario) {
        try {
            String sql = "SELECT imagen FROM usuario WHERE id = ?";
            PreparedStatement pstmt = this.getConexion().prepareStatement(sql);
            pstmt.setInt(1, idUsuario);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                byte[] bytes = rs.getBytes("imagen");
                if (bytes != null) {
                    ByteArrayInputStream bais = new ByteArrayInputStream(bytes);
                    Image image = new Image(bais);
                    imageView.setImage(image);
                    System.out.println("Imagen cargada desde la base de datos.");
                } else {
                    System.out.println("El usuario no tiene imagen guardada.");
                }
            }

            rs.close();
            pstmt.close();
            this.getConexion().close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }



}
