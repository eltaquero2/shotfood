package ConexionBD;

import ConexionBD.DBUtil;
import com.example.shotfood.Nutrientes;
import com.example.shotfood.Usuario;

import java.sql.*;
import java.util.ArrayList;

public class NutrientesModel extends DBUtil {

    public ArrayList<Nutrientes> getNutrientes() {

        ArrayList<Nutrientes> listaNutrientes = new ArrayList<Nutrientes>();

        try {
            //Iniciamos conexi�n
            String sql = "SELECT id, nombre FROM nutrientes";
            PreparedStatement stmt = this.getConexion().prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();

            while(rs.next()) {

                int id = rs.getInt("id");
                String nombre = rs.getString("nombre");

                Nutrientes u = new Nutrientes(id, nombre);
                listaNutrientes.add(u);
            }

            return listaNutrientes;

        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
        finally {
            //Cerramos conexi�n
            this.cerrarConexion();
        }
    }

    public Nutrientes getNutrientePorId(int idUsuario, int idNutriente) {
        Nutrientes nutriente = null;

        String sql = "SELECT n.id, n.nombre, nu.objetivo, nu.seguimiento " +
                "FROM nutrientes n " +
                "JOIN nutrientes_usuario nu ON nu.id_nutriente = n.id " +
                "WHERE nu.id_usuario = ? AND nu.id_nutriente = ?";

        try (PreparedStatement stmt = this.getConexion().prepareStatement(sql)) {
            stmt.setInt(1, idUsuario);
            stmt.setInt(2, idNutriente);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                int id = rs.getInt("id");
                String nombre = rs.getString("nombre");
                int objetivo = rs.getInt("objetivo");
                int seguimiento = rs.getInt("seguimiento");

                nutriente = new Nutrientes(id, nombre, objetivo, seguimiento); // Asegúrate de que este constructor exista
            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            this.cerrarConexion();
        }

        return nutriente;
    }

    public boolean updateSeguimiento(int id_usuario, int id_nutriente, int seguimiento) {
        String sql = "UPDATE nutrientes_usuario SET seguimiento = ? WHERE id_usuario = ? AND id_nutriente = ?";

        try (PreparedStatement stmt = this.getConexion().prepareStatement(sql)) {
            stmt.setInt(1, seguimiento);
            stmt.setInt(2, id_usuario);
            stmt.setInt(3, id_nutriente);

            int filasAfectadas = stmt.executeUpdate();
            return filasAfectadas > 0;

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public Integer getSeguimientoNutriente(int idUsuario, int idNutriente) {
        String selectSql = "SELECT seguimiento FROM nutrientes_usuario WHERE id_usuario = ? AND id_nutriente = ?";
        Integer seguimiento = null;

        try (PreparedStatement stmt = this.getConexion().prepareStatement(selectSql)) {
            stmt.setInt(1, idUsuario);
            stmt.setInt(2, idNutriente);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                seguimiento = rs.getInt("seguimiento");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            this.cerrarConexion();
        }

        return seguimiento;
    }

    public String getNombreNutriente(int idUsuario, int idNutriente) {
        String selectSql = "SELECT n.nombre FROM nutrientes n " +
                "INNER JOIN nutrientes_usuario nu ON nu.id_nutriente = n.id " +
                "WHERE nu.id_usuario = ? AND nu.id_nutriente = ?";

        String nombre = null;

        try (PreparedStatement stmt = this.getConexion().prepareStatement(selectSql)) {
            stmt.setInt(1, idUsuario);
            stmt.setInt(2, idNutriente);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                nombre = rs.getString("nombre");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            this.cerrarConexion();
        }

        return nombre;
    }

    public boolean asignarObjetivo(int id_usuario, int id_nutriente, int objetivo){
        String sql = "UPDATE nutrientes_usuario SET objetivo = ? WHERE id_usuario = ? AND id_nutriente = ?";

        try (PreparedStatement stmt = this.getConexion().prepareStatement(sql)) {
            stmt.setInt(1, objetivo);
            stmt.setInt(2, id_usuario);
            stmt.setInt(3, id_nutriente);

            int filasAfectadas = stmt.executeUpdate();
            return filasAfectadas > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        } finally {
            this.cerrarConexion();
        }
    }


}
