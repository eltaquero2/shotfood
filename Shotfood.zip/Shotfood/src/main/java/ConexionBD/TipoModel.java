package ConexionBD;

import com.example.shotfood.Tipo;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class TipoModel extends DBUtil {

    public ArrayList<Tipo> getTipos() {

        ArrayList<Tipo> listaTipos = new ArrayList<Tipo>();

        try {
            //Iniciamos conexi�n
            String sql = "SELECT id, nombre FROM tipo";
            PreparedStatement stmt = this.getConexion().prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();

            while(rs.next()) {

                int id = rs.getInt("id");
                String nombre = rs.getString("nombre");

                Tipo t = new Tipo(id, nombre);
                listaTipos.add(t);
            }

            return listaTipos;

        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
        finally {
            //Cerramos conexi�n
            this.cerrarConexion();
        }
    }

}
