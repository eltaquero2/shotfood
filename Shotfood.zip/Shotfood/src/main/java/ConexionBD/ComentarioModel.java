package ConexionBD;

public class ComentarioModel {
}
