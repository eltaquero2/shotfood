module com.example.shotfood {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;
    requires mysql.connector.j;
    requires javafx.swing;


    opens com.example.shotfood to javafx.fxml;
    exports com.example.shotfood;
    exports ConexionBD;
    opens ConexionBD to javafx.fxml;
    exports Controllers;
    opens Controllers to javafx.fxml;
}