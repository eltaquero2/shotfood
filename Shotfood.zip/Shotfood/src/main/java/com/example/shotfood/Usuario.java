package com.example.shotfood;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Usuario {
    private int id;
    private String nombre;
    private String contraseña;
    private boolean admin;

    private static Usuario usuarioActual;

    public Usuario() {
    }

    public Usuario(String nombre, String contraseña) {
        this.nombre = nombre;
        this.contraseña = contraseña;

        // Buscar en base de datos si es admin
        ConexionBD.DBUtil db = new ConexionBD.DBUtil();
        Connection conn = db.getConexion();

        String sql = "SELECT admin, id FROM usuario WHERE nombre = ? AND contraseña = ?";

        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, nombre);
            stmt.setString(2, contraseña);

            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                this.admin = rs.getBoolean("admin");
                this.id = rs.getInt("id");
            } else {
                // Usuario no encontrado, podrías lanzar una excepción si quieres
                this.admin = false;
                this.id = -1;
            }

        } catch (SQLException e) {
            e.printStackTrace();
            this.admin = false;
            this.id = -1;
        } finally {
            db.cerrarConexion();
        }
    }

    public Usuario(int id, String nombre, String contraseña, boolean admin) {
        this.id = id;
        this.nombre = nombre;
        this.contraseña = contraseña;
        this.admin = admin;
    }

    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public String getContraseña() {
        return contraseña;
    }

    public boolean isAdmin() {
        return admin;
    }

    public void setAdmin(boolean admin) {
        this.admin = admin;
    }

    public static void setUsuarioActual(Usuario usuario) {
        usuarioActual = usuario;
    }

    public static Usuario getUsuarioActual() {
        return usuarioActual;
    }
}
