package com.example.shotfood;

import javafx.collections.ObservableList;

public class Nutrientes {

    private int id = 0;
    private String nombre = "";
    private int objetivo = 0;
    private int seguimiento = 0;

    public Nutrientes(int id,String nombre, int objetivo, int seguimiento) {
        this.id = id;
        this.nombre = nombre;
        this.objetivo = objetivo;
        this.seguimiento = seguimiento;

    }

    public Nutrientes(String nombre, int objetivo, int seguimiento) {
        this.nombre = nombre;
        this.objetivo = objetivo;
        this.seguimiento = seguimiento;

    }

    public Nutrientes(int objetivo, int seguimiento){
        this.objetivo = objetivo;
        this.seguimiento = seguimiento;

    }

    public Nutrientes(int id, String nombre){
        this.id = id;
        this.nombre = nombre;
    }

    public Nutrientes() {

    }

    public int getId(){
        return this.id;
    }

    public String getNombre(){
        return this.nombre;
    }

    public int getObjetivo(){
        return this.objetivo;
    }

    public int seguimiento(){
        return this.seguimiento;
    }

    public double porcentajeSeguimiento(){
        double multiplicacion = this.seguimiento * 100;
        double division = multiplicacion / this.objetivo;

        return division;
    }
}
