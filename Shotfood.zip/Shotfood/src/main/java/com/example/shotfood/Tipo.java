package com.example.shotfood;

public class Tipo {

    int id;
    String nombre;

    public Tipo(int id, String nombre) {
        this.id = id;
        this.nombre = nombre;
    }

    public Tipo(String nombre) {
        this.nombre = nombre;
    }

    public Tipo() {}

    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

}
