package com.example.shotfood;

public class Publicacion {
    private int id;
    private int recetaId;
    private String usuario;
    private String texto;
    private String fecha;

    public Publicacion(int id, int recetaId, String usuario, String texto, String fecha) {
        this.id = id;
        this.recetaId = recetaId;
        this.usuario = usuario;
        this.texto = texto;
        this.fecha = fecha;
    }

    public int getId() { return id; }
    public int getRecetaId() { return recetaId; }
    public String getUsuario() { return usuario; }
    public String getTexto() { return texto; }
    public String getFecha() { return fecha; }

    public void setId(int id) { this.id = id; }
    public void setRecetaId(int recetaId) { this.recetaId = recetaId; }
    public void setUsuario(String usuario) { this.usuario = usuario; }
    public void setTexto(String texto) { this.texto = texto; }
    public void setFecha(String fecha) { this.fecha = fecha; }
}