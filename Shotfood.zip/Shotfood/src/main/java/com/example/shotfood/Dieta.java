package com.example.shotfood;

import ConexionBD.TipoModel;

import java.util.ArrayList;

public class Dieta {
    int id;
    int tipo;
    String nombre;
    ArrayList<Receta> recetas = new ArrayList<Receta>();


    public Dieta(int id, int tipo, String nombre) {
        this.id = id;
        this.tipo = tipo;
        this.nombre = nombre;
    }

    public Dieta(int tipo, String nombre) {
        this.tipo = tipo;
        this.nombre = nombre;
    }

    public Dieta() {

    }

    public String tipoString() {
        String nombre = null;

        TipoModel tm = new TipoModel();

        for (Tipo t : tm.getTipos()) {
            int id_tipo = t.getId();
            if (this.tipo == id_tipo) {
                nombre = t.getNombre();
                break;
            }
        }

        return nombre;
    }

    public String getNombre(){
        return this.nombre;
    }

    public int getTipo(){
        return this.tipo;
    }
}