package com.example.shotfood;

public class Receta {
    private int id;
    private String nombre;
    private String ingredientes;
    private String texto;
    private String fecha_creacion;
    private int duracion;
    private String imagen; // Ruta relativa de la imagen

    public Receta(int id, String nombre, String ingredientes, String texto, String fecha_creacion, int duracion, String imagen) {
        this.id = id;
        this.nombre = nombre;
        this.ingredientes = ingredientes;
        this.texto = texto;
        this.fecha_creacion = fecha_creacion;
        this.duracion = duracion;
        this.imagen = imagen;
    }

    // Getters y Setters normales
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }
    public String getIngredientes() { return ingredientes; }
    public void setIngredientes(String ingredientes) { this.ingredientes = ingredientes; }
    public String getTexto() { return texto; }
    public void setTexto(String texto) { this.texto = texto; }
    public String getFecha_creacion() { return fecha_creacion; }
    public void setFecha_creacion(String fecha_creacion) { this.fecha_creacion = fecha_creacion; }
    public int getDuracion() { return duracion; }
    public void setDuracion(int duracion) { this.duracion = duracion; }

    // Métodos para imagen
    public String getImagen() { return imagen; }
    public void setImagen(String imagen) { this.imagen = imagen; }

    // Método que devuelve la ruta de la imagen para cargar desde classpath
    public String getImagenResourcePath() {
        if (imagen == null || imagen.isEmpty()) {
            return "/images/default.png";
        }

        // Si la imagen ya comienza con /, asumimos que es una ruta de recurso
        if (imagen.startsWith("/")) {
            return imagen;
        }

        // Si no, aseguramos que tenga formato de ruta de recurso
        return "/images/" + imagen;
    }
}